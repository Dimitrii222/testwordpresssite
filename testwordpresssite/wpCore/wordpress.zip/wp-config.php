<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'wptest');

/** Имя пользователя MySQL */
define('DB_USER', 'root');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', '');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '?.W5k |j@r@htlF~xTgZDGflT?<_D@(jIsCPpolR2Qm*0QNR={WB`};a:sT5[u!Q');
define('SECURE_AUTH_KEY',  '$?3WhJTCFiQHV?H&zNHG25;w18U>BB[H$W|:d}b8>5vIHbH1GXQ[Z(=NtOHPSom;');
define('LOGGED_IN_KEY',    '[n27hHaY*wuj^%s9)Yc}:O-X;l/W!*t]$8t%pHf,BOdCd&,ZZ(JsK1BFUV+UvEEX');
define('NONCE_KEY',        '<eQK%CS&p(cZQH-_C=!Ic xVcLEuI%6N!stn#YPI_l|XvAbh_*%M1x//cg1D]5SJ');
define('AUTH_SALT',        'DR{KL{U[s^R`<{Oz`utmuf2l6Q]U8~q{)DX(7Ppr?8px=G>he0uV4|/Sj{{x0 P%');
define('SECURE_AUTH_SALT', '&s0+qTV8gRcu7Jzwxnw)OlyR#KB`>cx}9!`F}v51.%D?8w#}WR#XpK!H`:d3mUyp');
define('LOGGED_IN_SALT',   'Q2NSghO9zKSM3eBiycGx!-+CxOZgs:ACXPE}TGawuyr K~$.FH, M1wh4zCVb@w8');
define('NONCE_SALT',       'q6z=uqXakAr1v2ygFICu#t-f8J^%|PFVy FVQr8Hu9>(EN^pl6e{c%war 3t*H1p');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 * 
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
